
This is the program for team registration.

You need to make changes on rtclient.cpp for your team name and student IDs.

To compile and build --

$ make

To register --

$ ./rtclient

If successful, your team has been registered.

