Team member: 2

Team member 1:
Name: Jason Zhang 
SID: 918743132
Email: jzzh@ucdavis.edu 

Team member 2:
Name: Hari
SID: Unknown
Email: Unknown 

Note:
The other team member's name is Hari.
He has not contributed to the group work at all during the process. 
Neither do I receive his full name, his email and SID for the team registration.
All codings are being done on my end alone (Jason Zhang). 

